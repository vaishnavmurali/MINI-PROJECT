"""AttendanceManagement path Configuration

The `pathpatterns` list routes paths to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/paths/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a path to pathpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a path to pathpatterns:  path('', Home.as_view(), name='home')
Including another pathconf
    1. Add a path to pathpatterns:  path('blog/', include('blog.paths'))
"""
# from django.conf.paths import include, path
from django.urls import path
from django.contrib import admin
from Attendanceapp.views import *
from django.views.generic import TemplateView
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns





urlpatterns = [
    # path('admin/', admin.site.urls),
    path('admin/', admin.site.urls),
    path('',index,name="index"),
    path('index/',index,name="index"),
    path('logaction/',logaction,name="logaction"),
    path('adminhome/',adminhome,name="adminhome"),
    path('facultyhome/',facultyhome,name="facultyhome"),
    path('logout/',logout,name="logout"),
    

]
