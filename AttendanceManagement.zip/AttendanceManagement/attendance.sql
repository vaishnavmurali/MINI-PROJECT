-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 12, 2025 at 01:46 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `attendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE IF NOT EXISTS `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `auth_group`
--


-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissi_permission_id_23962d04_fk_auth_permission_id` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `auth_group_permissions`
--


-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE IF NOT EXISTS `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can add permission', 2, 'add_permission'),
(5, 'Can change permission', 2, 'change_permission'),
(6, 'Can delete permission', 2, 'delete_permission'),
(7, 'Can add group', 3, 'add_group'),
(8, 'Can change group', 3, 'change_group'),
(9, 'Can delete group', 3, 'delete_group'),
(10, 'Can add user', 4, 'add_user'),
(11, 'Can change user', 4, 'change_user'),
(12, 'Can delete user', 4, 'delete_user'),
(13, 'Can add content type', 5, 'add_contenttype'),
(14, 'Can change content type', 5, 'change_contenttype'),
(15, 'Can delete content type', 5, 'delete_contenttype'),
(16, 'Can add session', 6, 'add_session'),
(17, 'Can change session', 6, 'change_session'),
(18, 'Can delete session', 6, 'delete_session');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE IF NOT EXISTS `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `auth_user`
--


-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE IF NOT EXISTS `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_30a071c9_fk_auth_group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `auth_user_groups`
--


-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE IF NOT EXISTS `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_perm_permission_id_3d7071f0_fk_auth_permission_id` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `auth_user_user_permissions`
--


-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE IF NOT EXISTS `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin__content_type_id_5151027a_fk_django_content_type_id` (`content_type_id`),
  KEY `django_admin_log_user_id_1c5f563_fk_auth_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `django_admin_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE IF NOT EXISTS `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_3ec8c61c_uniq` (`app_label`,`model`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE IF NOT EXISTS `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2023-02-28 08:02:53'),
(2, 'auth', '0001_initial', '2023-02-28 08:02:53'),
(3, 'admin', '0001_initial', '2023-02-28 08:02:53'),
(4, 'contenttypes', '0002_remove_content_type_name', '2023-02-28 08:02:53'),
(5, 'auth', '0002_alter_permission_name_max_length', '2023-02-28 08:02:54'),
(6, 'auth', '0003_alter_user_email_max_length', '2023-02-28 08:02:54'),
(7, 'auth', '0004_alter_user_username_opts', '2023-02-28 08:02:54'),
(8, 'auth', '0005_alter_user_last_login_null', '2023-02-28 08:02:54'),
(9, 'auth', '0006_require_contenttypes_0002', '2023-02-28 08:02:54'),
(10, 'sessions', '0001_initial', '2023-02-28 08:02:54');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_de54fa62` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('11j3gdarnt8dw5iwj1xpe03vbodmkmjx', 'OTE5OGU2MGJiOGY4OTNkZWZkYWI5ZDY4ZDlhYjk5Y2U0OTBlYTdlNTp7InVuYW1lIjoiYWRtaW5AZ21haWwuY29tIn0=', '2023-07-17 10:26:02'),
('1lnlpu6svl7kyqnohymubqcgplw7cdpu', 'eyJ1aWQiOjEsInVuYW1lIjoibWF5YUBnbWFpbC5jb20iLCJ1dHlwZSI6InBhcmVudCJ9:1rpLOv:9VQ1idoy4WYVPdVFCvpLQOgWWymYjViXpa-OfcOHO88', '2024-04-10 05:00:37'),
('1seq9yuelymcrnugy6ayo479pb9bzyq4', 'eyJ1bmFtZSI6InNuZWhhQGdtYWlsLmNvbSIsInVpZCI6MSwidXR5cGUiOiJmYWN1bHR5In0:1rgHL3:XZ85FoJz13-goBTZ8KeKgjNqYohHYCvqCL1YnDaQcus', '2024-03-16 04:51:09'),
('2v4ux5fk3eyocrfus2hikoomlqa2ckrl', 'MDlmMzRlMmUxYTU3MTA3YTk1OGM0MzY5OWM5YjM0OWZhMWZkYjMwOTp7InV0eXBlIjoiZmFjdWx0eSIsInVuYW1lIjoic25laGExMkBnbWFpbC5jb20iLCJ1aWQiOjd9', '2023-03-27 04:07:03'),
('4gysby7l1hqhulv0oj4vbsb86xtrwnhe', 'eyJ1bmFtZSI6ImFkbWluIn0:1riT8r:8cjc6si4K8qacX4AwPWXproeG-0eUApSRDT--VVEbLU', '2024-03-22 05:51:37'),
('5xcbqlfi3wup8owp2gq9rrxvyso8odfi', 'eyJ1aWQiOjEsInVuYW1lIjoic25laGFAZ21haWwuY29tIiwidXR5cGUiOiJmYWN1bHR5In0:1rfvJK:SwJvjf8uOtdNJ1wOtT31-HhNLjBJ9LAvTj7YGX0Q65M', '2024-03-15 05:19:54'),
('b13y58jhcibhz26xql8r48b44s66id3b', '.eJyrVirNTFGyMtBRKs1LzE1VslJKTMnNzFMC8ksqCxD8WgANQQ0k:1ulpGD:42IW2WhPbE1atlGG_-Dx1v6cw0RLqR9AjFxk2L5kMsQ', '2025-08-26 13:41:53'),
('bs5ectrp6e2rmornb1piv89xjxe4xu8d', '.eJyrVirNS8xNVbJSSkzJzcxT0lEqzUxRsjIA0iWVBQjxWgAT6Q0k:1rwzHV:bkVmQhdZWiFQ9U8EhMUUWFQsA1TDhme9REkRCBsHNMo', '2024-05-01 07:00:33'),
('emvb1oookko67fusu0phv5y1dvw2qvud', 'NTQ4YmMxZjA1OWI2N2JkYWRkOTE2ODk5OGIxYmU2ZWNiN2M4YWM1NTp7InV0eXBlIjoiYWRtaW4iLCJ1bmFtZSI6ImFkbWluQGdtYWlsLmNvbSIsInVpZCI6MH0=', '2023-03-14 08:02:59'),
('ewrc2odbpmnvmtms7rbjapx5rzlshkj3', '.eJyrVirNTFGyMtBRKs1LzE1VslJKTMnNzFMC8ksqCxD8WgANQQ0k:1tzrJe:74hwCZzUsPKCG-MBTPhhXoMlU8TlVbiXNbiL7JGK3lA', '2025-04-16 06:11:10'),
('ghdapxf61ehwzccru9ui7h8jeqfh8pvv', 'eyJ1bmFtZSI6InNuZWhhQGdtYWlsLmNvbSIsInVpZCI6MSwidXR5cGUiOiJmYWN1bHR5In0:1retKZ:uBufHsdaBwUgf4uHTKhDyifmvt3i9vfbFmRq-T65xI8', '2024-03-12 09:00:55'),
('m5ubk6eztk3cm89o70kiw0v7t3myju7r', '.eJyrVirNS8xNVbJSSkzJzcxT0lEqzUxRsjIA0iWVBQjxWgAT6Q0k:1rirXh:JQzopADvc1ccwhO6uMlxg0U09oo1DxLSRPyPsg1G2WA', '2024-03-23 07:54:53'),
('nvzpkmo4i1k9aqo1buo9iv835scniymw', 'eyJ1bmFtZSI6Im1heWFAZ21haWwuY29tIiwidWlkIjoxLCJ1dHlwZSI6InBhcmVudCJ9:1rpNqE:hbN2ZFlWRbFgqR8-Z_XvfyTjc2jM033tAsT1TaCrzLg', '2024-04-10 07:36:58'),
('r45h6orw1ii115yjll55tcsk240ovvps', 'eyJ1bmFtZSI6ImFtYWxAZ21haWwuY29tIiwidWlkIjoyLCJ1dHlwZSI6ImZhY3VsdHkifQ:1rnbJn:6aZo5wkW225hwaV5-dSzHR_sTiOJuB9_7YNeEIo_eyc', '2024-04-05 09:36:07'),
('twv2wb3tuarevj1j0yaleq3ouafthm7r', 'eyJ1aWQiOjEsInVuYW1lIjoic25laGFAZ21haWwuY29tIiwidXR5cGUiOiJmYWN1bHR5In0:1rfeDw:Rt9RBEPDz9H8ZKNh1FKyqVTjpGXUXzap5NO9TAOOOiI', '2024-03-14 11:05:12'),
('uo6zmw4rujptdediqu4y38jzhks6a1ul', '.eJyrVirNS8xNVbJSSkzJzcxT0lEqzUxRsjIA0iWVBQjxWgAT6Q0k:1rgKnh:a4KtfrQq_mdi61fVmpmPxbEj1PXN6PRqG32EHGzG3NY', '2024-03-16 08:32:57'),
('x3srh0x40k2g1nhio1kxah6nyfhlctpv', '.eJyrVirNS8xNVbJSSkzJzcxT0lEqzUxRsjIA0iWVBQjxWgAT6Q0k:1rnxGd:lTP1gWG7i3_A_qk1wkJv5u-ZJOmJuaIxKGnDxCV2qJM', '2024-04-06 09:02:19');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_faculty`
--

CREATE TABLE IF NOT EXISTS `tbl_faculty` (
  `facid` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(20) NOT NULL,
  `hname` varchar(20) NOT NULL,
  `street` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `pin` int(11) NOT NULL,
  `dob` varchar(10) NOT NULL,
  `qual` varchar(1000) NOT NULL,
  `exp` varchar(1000) NOT NULL,
  `phno` varchar(20) NOT NULL,
  `deptid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`facid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_faculty`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE IF NOT EXISTS `tbl_login` (
  `uid` int(11) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `upass` varchar(20) NOT NULL,
  `utype` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`uid`, `uname`, `upass`, `utype`) VALUES
(0, 'admin', 'admin', 'admin');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissions_group_id_58c48ba9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_group_permissi_permission_id_23962d04_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permissi_content_type_id_51277a81_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_30a071c9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_24702650_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permissions_user_id_7cd7acb6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  ADD CONSTRAINT `auth_user_user_perm_permission_id_3d7071f0_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_user_id_1c5f563_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  ADD CONSTRAINT `django_admin__content_type_id_5151027a_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);
