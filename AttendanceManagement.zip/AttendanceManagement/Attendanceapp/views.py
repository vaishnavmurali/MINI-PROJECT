from django.shortcuts import render
from django.http import HttpResponse
from django.db import connection
from django.shortcuts import HttpResponseRedirect,redirect
from datetime import date
import datetime
today_date = datetime.date.today()
today = today_date.strftime("%Y-%m-%d")

def index(request):
    return render(request,'index.html')
def parenthome(request):
    return render(request,'parenthome.html')
def parent(request):
    return render(request,'parent.html')

def logaction(request):
    cursor=connection.cursor()
    un = request.GET['usrnm']
    up = request.GET['pswd']
    sql = "select * from tbl_login where uname='%s' and upass='%s'"%(un,up)
    cursor.execute(sql)
    if (cursor.rowcount)>0:
        rs=cursor.fetchall()
        for row in rs:
            request.session['uid']=row[0]
            request.session['uname']=row[1]
            request.session['utype']=row[3]
        if (request.session['utype']=="admin"):
            msg="<script>alert('Welcome Admin');window.location='/adminhome/'</script>"
            return HttpResponse(msg)
        elif (request.session['utype']=="faculty"):
            msg="<script>alert('Welcome Faculty');window.location='/facultyhome/';</script>"
            return HttpResponse(msg)
        elif (request.session['utype']=="parent"):
            msg="<script>alert('Welcome Parent');window.location='/parenthome/';</script>"
            return HttpResponse(msg)
        elif (request.session['utype']=="student"):
            message="<script>alert('Welcome Student');window.location='/studenthome/';</script>"
            return HttpResponse(message)
        elif (request.session['utype']=="hod"):
            message="<script>alert('Welcome Head Of The Department');window.location='/hodhome/';</script>"
            return HttpResponse(msg)
        
        else:
            msg="<script>alert('Login Failed');window.location='/index/';</script>"
            return HttpResponse(msg)
        
    else:
        msg="<script>alert('Login Failed');window.location='/index/'</script>"
        return HttpResponse(msg)
def adminhome(request):
    return render(request,'adminhome.html')
def logout(request):
	try:
		del request.session['uid']
		del request.session['utype']
	except:
		pass
	return HttpResponse("<script>alert('you are loged out');window.location='/index/';</script>")
def facultyhome(request):
    return render(request,'facultyhome.html')
def studenthome(request):
    return render(request,'studenthome.html')
    
def facultyhome(request):
    return render(request,'facultyhome.html')

       